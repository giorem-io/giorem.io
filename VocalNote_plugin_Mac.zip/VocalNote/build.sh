#!/bin/bash
# Compila e instala VocalNote (VST3 + AU) en tu Mac.
# Uso: en Terminal, entra a esta carpeta y corre:  bash build.sh
set -e
cd "$(dirname "$0")"

echo "== VocalNote: compilando para tu Mac =="

# 1) Herramientas de compilación de Apple (gratis, ~1 GB, solo la primera vez)
if ! xcode-select -p >/dev/null 2>&1; then
    echo "Hace falta instalar las 'Command Line Tools' de Apple."
    echo "Se abrirá una ventana: dale a Instalar. Cuando termine, vuelve a correr: bash build.sh"
    xcode-select --install || true
    exit 1
fi

# 2) CMake (si no lo tienes, se descarga una copia local en ./tools, no toca tu sistema)
CMAKE="$(command -v cmake || true)"
if [ -z "$CMAKE" ]; then
    CMAKE="$PWD/tools/CMake.app/Contents/bin/cmake"
    if [ ! -x "$CMAKE" ]; then
        echo "Descargando CMake (solo la primera vez)..."
        mkdir -p tools
        curl -L --fail -o tools/cmake.tar.gz \
            https://github.com/Kitware/CMake/releases/download/v3.30.5/cmake-3.30.5-macos-universal.tar.gz
        tar -xzf tools/cmake.tar.gz -C tools --strip-components=1
        rm tools/cmake.tar.gz
    fi
fi

# 3) Compilar (descarga JUCE la primera vez; tarda unos minutos)
ARCH="$(uname -m)"   # arm64 en Apple Silicon, x86_64 en Intel
"$CMAKE" -B build -DCMAKE_BUILD_TYPE=Release -DCMAKE_OSX_ARCHITECTURES="$ARCH"
"$CMAKE" --build build --config Release -j "$(sysctl -n hw.ncpu)"

# 4) Ya quedó copiado en ~/Library/Audio/Plug-Ins/{VST3,Components}. Refrescar el registro de AU:
killall -9 AudioComponentRegistrar >/dev/null 2>&1 || true

echo ""
echo "Listo. Instalado en:"
echo "  ~/Library/Audio/Plug-Ins/VST3/VocalNote.vst3"
echo "  ~/Library/Audio/Plug-Ins/Components/VocalNote.component"
echo ""
echo "Comprobando el AU con la herramienta de Apple (auval)..."
if auval -v aumf Vcn1 Vcnt 2>/dev/null | grep -q "AU VALIDATION SUCCEEDED"; then
    echo "  AU validado correctamente."
else
    echo "  (auval no lo pudo validar todavía; el VST3 funciona igual. Reinicia la Mac si Ableton no ve el AU.)"
fi
echo ""
echo "Abre Ableton > Preferencias > Plug-ins > 'Volver a escanear'. Busca VocalNote en Plug-ins."
