# VocalNote: corrección de voz nota por nota con MIDI

VocalNote es un plugin VST3/AU para Ableton Live. Lo pones en tu pista de voz y la voz va a la nota MIDI que dibujes en el piano roll. Cada nota que dibujas controla la sílaba que suena en ese momento.

## 1. Instalar (una sola vez)

1. Descomprime el zip, por ejemplo en tu carpeta Descargas.
2. Abre **Terminal**.
3. Escribe `cd ` (con un espacio al final), arrastra la carpeta **VocalNote** a la ventana de Terminal y presiona Enter.
4. Escribe `bash build.sh` y presiona Enter.
   - Si te pide instalar las "Command Line Tools" de Apple, acepta. Cuando termine, vuelve a correr `bash build.sh`.
   - La primera vez tarda entre 5 y 10 minutos, porque descarga JUCE y compila el plugin.
5. En Ableton, ve a **Preferencias → Plug-ins**. Activa **"Use VST3 Plug-in System Folders"** y presiona **Volver a escanear**.

El plugin queda instalado en `~/Library/Audio/Plug-Ins/VST3/VocalNote.vst3` y en `~/Library/Audio/Plug-Ins/Components/VocalNote.component`.

## 2. Usarlo en Ableton

1. Arrastra **VocalNote** (en Plug-ins) a la pista de audio que tiene la voz.
2. Crea una **pista MIDI** nueva.
3. En la sección **I/O** de esa pista MIDI, cambia **"MIDI To"** a tu pista de voz. En el selector de abajo elige **VocalNote**.
4. Dibuja notas en el clip MIDI, una por cada sílaba o nota cantada. La voz se va a esas notas.
   - Si no hay nota MIDI en un momento, la voz suena original. Así puedes corregir solo las partes que quieras.
5. Activa la **monitorización** de la pista MIDI (In o Auto) y dale play.

En el gráfico del plugin vas a ver la voz original en gris, la nota MIDI en naranja y la voz corregida en turquesa.

## Controles

| Control | Qué hace |
|---|---|
| **Correccion** | Qué tanto se acerca la voz a la nota. Con 100 % llega exacta y con 50 % llega a medio camino. |
| **Velocidad** | En cuánto tiempo llega la voz a la nota. Con 0 ms suena como Auto-Tune duro o robot. Entre 20 y 60 ms suena natural, y con más de 100 ms la voz conserva el vibrato. |
| **Transponer** | Sube o baja todo ±12 semitonos sin mover las notas MIDI. |
| **Sensibilidad** | Súbela si el plugin no detecta partes de la voz. Bájala si corrige respiraciones o ruidos. |
| **Pitch Bend** | Rango del pitch bend en semitonos. Solo funciona en la versión AU. |
| **Mezcla** | Mezcla entre la voz original y la corregida. |
| **Mantener ultima nota** | Si está activado, cuando no hay nota MIDI la voz se queda en la última nota en lugar de volver a la original. |

## Notas

- **Una voz a la vez:** funciona con voces de una sola línea, no con coros ni armonías dentro del mismo audio.
- **Latencia:** el plugin agrega unos 60 ms de retraso. Ableton lo compensa solo, así que en reproducción todo queda alineado.
- **Formantes:** se conservan, así que la voz no suena a ardilla al subirla, siempre que muevas pocos semitonos. Con más de 5 semitonos ya se nota que está procesada.
- **Para fijar el resultado:** cuando te guste cómo suena, haz **Freeze + Flatten** de la pista de voz o resámplala. Así fijas el audio y liberas CPU.
