#include "PluginEditor.h"

namespace
{
    const juce::Colour bg     { 0xff15171c };
    const juce::Colour panel  { 0xff1e2129 };
    const juce::Colour accent { 0xff4fd1c5 };  // turquesa: voz detectada
    const juce::Colour target { 0xfff6ad55 };  // naranja: nota MIDI
    const juce::Colour text   { 0xffe2e8f0 };
    const juce::Colour dim    { 0xff718096 };

    juce::String noteName (float midi)
    {
        static const char* names[] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
        int n = (int) std::lround (midi);
        return juce::String (names[((n % 12) + 12) % 12]) + juce::String (n / 12 - 1);
    }
}

VocalNoteEditor::VocalNoteEditor (VocalNoteProcessor& p) : AudioProcessorEditor (&p), proc (p)
{
    lnf.setColour (juce::Slider::rotarySliderFillColourId, accent);
    lnf.setColour (juce::Slider::rotarySliderOutlineColourId, juce::Colour (0xff2d3340));
    lnf.setColour (juce::Slider::thumbColourId, text);
    lnf.setColour (juce::Slider::textBoxTextColourId, text);
    lnf.setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    lnf.setColour (juce::ToggleButton::textColourId, text);
    lnf.setColour (juce::ToggleButton::tickColourId, accent);
    setLookAndFeel (&lnf);

    const char* ids[]    = { "amount", "speed", "transpose", "sens", "bend", "mix" };
    const char* titles[] = { "Correccion", "Velocidad", "Transponer", "Sensibilidad", "Pitch Bend", "Mezcla" };
    for (size_t i = 0; i < knobs.size(); ++i)
    {
        auto& k = knobs[i];
        k.slider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
        k.slider.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 70, 18);
        addAndMakeVisible (k.slider);
        k.label.setText (titles[i], juce::dontSendNotification);
        k.label.setJustificationType (juce::Justification::centred);
        k.label.setColour (juce::Label::textColourId, dim);
        addAndMakeVisible (k.label);
        k.att = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (proc.apvts, ids[i], k.slider);
    }
    knobs[1].slider.setTooltip ("0 ms = efecto robot / Auto-Tune duro. 30-80 ms = natural.");
    knobs[3].slider.setTooltip ("Sube si la voz no se detecta; baja si corrige ruidos o respiraciones.");

    addAndMakeVisible (holdButton);
    holdAtt = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (proc.apvts, "hold", holdButton);

    histDet.fill (0.f); histTgt.fill (-1.f); histOut.fill (0.f);
    setSize (640, 420);
    startTimerHz (30);
}

VocalNoteEditor::~VocalNoteEditor() { setLookAndFeel (nullptr); }

void VocalNoteEditor::timerCallback()
{
    histDet[(size_t) histPos] = proc.uiDetected.load();
    histTgt[(size_t) histPos] = proc.uiTarget.load();
    histOut[(size_t) histPos] = proc.uiOut.load();
    histPos = (histPos + 1) % histLen;
    repaint();
}

void VocalNoteEditor::paint (juce::Graphics& g)
{
    g.fillAll (bg);

    // título
    g.setColour (text);
    g.setFont (juce::FontOptions (22.f, juce::Font::bold));
    g.drawText ("VocalNote", 20, 12, 200, 28, juce::Justification::centredLeft);
    g.setColour (dim);
    g.setFont (juce::FontOptions (13.f));
    g.drawText ("La voz sigue las notas MIDI que dibujes en Ableton", 160, 12, 460, 28, juce::Justification::centredRight);

    // gráfico de tono
    g.setColour (panel);
    g.fillRoundedRectangle (graphArea.toFloat(), 8.f);
    auto ga = graphArea.reduced (10, 8).toFloat();

    // rango vertical automático alrededor de lo reciente
    float lo = 1000.f, hi = -1000.f;
    for (int i = 0; i < histLen; ++i)
    {
        if (histDet[(size_t) i] > 0.f) { lo = std::min (lo, histDet[(size_t) i]); hi = std::max (hi, histDet[(size_t) i]); }
        if (histTgt[(size_t) i] >= 0.f) { lo = std::min (lo, histTgt[(size_t) i]); hi = std::max (hi, histTgt[(size_t) i]); }
    }
    if (lo > hi) { lo = 55.f; hi = 72.f; }
    float mid = 0.5f * (lo + hi);
    float span = std::max (12.f, hi - lo + 4.f);
    lo = mid - span / 2; hi = mid + span / 2;
    auto yOf = [&] (float m) { return ga.getBottom() - (m - lo) / (hi - lo) * ga.getHeight(); };

    // líneas de semitono y nombres de C
    for (int m = (int) std::ceil (lo); m <= (int) hi; ++m)
    {
        bool isC = (m % 12) == 0;
        g.setColour (isC ? juce::Colour (0xff3a4150) : juce::Colour (0xff252a33));
        g.drawHorizontalLine ((int) yOf ((float) m), ga.getX(), ga.getRight());
        if (isC || (span <= 14.f))
        {
            g.setColour (dim);
            g.setFont (juce::FontOptions (10.f));
            g.drawText (noteName ((float) m), (int) ga.getX() + 2, (int) yOf ((float) m) - 11, 30, 10, juce::Justification::left);
        }
    }

    const float dx = ga.getWidth() / (float) (histLen - 1);
    // notas objetivo (barras)
    g.setColour (target.withAlpha (0.85f));
    for (int k = 0; k < histLen; ++k)
    {
        float v = histTgt[(size_t) ((histPos + k) % histLen)];
        if (v >= 0.f) g.fillRect (ga.getX() + k * dx, yOf (v) - 3.f, dx + 0.6f, 6.f);
    }
    auto drawLine = [&] (const std::array<float, histLen>& h, juce::Colour c, float thick)
    {
        juce::Path path; bool started = false;
        for (int k = 0; k < histLen; ++k)
        {
            float v = h[(size_t) ((histPos + k) % histLen)];
            if (v <= 0.f) { started = false; continue; }
            float x = ga.getX() + k * dx, y = yOf (v);
            if (! started) { path.startNewSubPath (x, y); started = true; } else path.lineTo (x, y);
        }
        g.setColour (c);
        g.strokePath (path, juce::PathStrokeType (thick));
    };
    drawLine (histDet, dim.withAlpha (0.7f), 1.2f);   // voz original
    drawLine (histOut, accent, 2.2f);                 // voz corregida

    // lectura numérica
    float det = proc.uiDetected.load(), tg = proc.uiTarget.load(), outv = proc.uiOut.load();
    auto fmt = [] (float m) { return m > 0.f ? noteName (m) + juce::String::formatted (" %+d c", (int) std::lround ((m - std::round (m)) * 100.f)) : juce::String ("--"); };
    juce::String s2 = tg >= 0.f ? noteName (tg) : "sin nota";
    g.setFont (juce::FontOptions (14.f, juce::Font::bold));
    const int lx = graphArea.getX() + 50, ly = graphArea.getY() + 6;
    g.setColour (dim);     g.drawText ("Original: " + fmt (det),  lx,       ly, 170, 18, juce::Justification::left);
    g.setColour (accent);  g.drawText ("Corregida: " + fmt (outv), lx + 175, ly, 180, 18, juce::Justification::left);
    g.setColour (target);  g.drawText ("MIDI: " + s2,             lx + 365, ly, 150, 18, juce::Justification::left);

    if (! proc.uiMidiSeen.load())
    {
        g.setColour (dim);
        g.setFont (juce::FontOptions (12.f));
        g.drawFittedText ("Aun no llega MIDI. En una pista MIDI elige  MIDI To -> esta pista -> VocalNote",
                          graphArea.reduced (20).removeFromBottom (24), juce::Justification::centred, 1);
    }
}

void VocalNoteEditor::resized()
{
    auto r = getLocalBounds().reduced (16);
    r.removeFromTop (34);
    graphArea = r.removeFromTop (190);
    r.removeFromTop (10);
    auto bottom = r.removeFromBottom (26);
    holdButton.setBounds (bottom.removeFromLeft (240));
    const int w = r.getWidth() / (int) knobs.size();
    for (auto& k : knobs)
    {
        auto c = r.removeFromLeft (w);
        k.label.setBounds (c.removeFromTop (18));
        k.slider.setBounds (c.reduced (4, 0));
    }
}
