#include "PluginProcessor.h"
#include "PluginEditor.h"

VocalNoteProcessor::VocalNoteProcessor()
    : AudioProcessor (BusesProperties()
                        .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                        .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "PARAMS", createLayout())
{
    pAmount    = apvts.getRawParameterValue ("amount");
    pSpeed     = apvts.getRawParameterValue ("speed");
    pBend      = apvts.getRawParameterValue ("bend");
    pHold      = apvts.getRawParameterValue ("hold");
    pMix       = apvts.getRawParameterValue ("mix");
    pTranspose = apvts.getRawParameterValue ("transpose");
    pSens      = apvts.getRawParameterValue ("sens");
}

juce::AudioProcessorValueTreeState::ParameterLayout VocalNoteProcessor::createLayout()
{
    using namespace juce;
    std::vector<std::unique_ptr<RangedAudioParameter>> p;
    p.push_back (std::make_unique<AudioParameterFloat> (ParameterID { "amount", 1 }, "Correccion",
                    NormalisableRange<float> (0.f, 100.f, 1.f), 100.f, AudioParameterFloatAttributes().withLabel ("%")));
    p.push_back (std::make_unique<AudioParameterFloat> (ParameterID { "speed", 1 }, "Velocidad",
                    NormalisableRange<float> (0.f, 400.f, 1.f, 0.4f), 25.f, AudioParameterFloatAttributes().withLabel ("ms")));
    p.push_back (std::make_unique<AudioParameterInt>   (ParameterID { "transpose", 1 }, "Transponer", -12, 12, 0));
    p.push_back (std::make_unique<AudioParameterFloat> (ParameterID { "sens", 1 }, "Sensibilidad",
                    NormalisableRange<float> (0.f, 100.f, 1.f), 50.f, AudioParameterFloatAttributes().withLabel ("%")));
    p.push_back (std::make_unique<AudioParameterFloat> (ParameterID { "bend", 1 }, "Rango Pitch Bend",
                    NormalisableRange<float> (0.f, 12.f, 1.f), 2.f, AudioParameterFloatAttributes().withLabel ("st")));
    p.push_back (std::make_unique<AudioParameterBool>  (ParameterID { "hold", 1 }, "Mantener ultima nota", false));
    p.push_back (std::make_unique<AudioParameterFloat> (ParameterID { "mix", 1 }, "Mezcla",
                    NormalisableRange<float> (0.f, 100.f, 1.f), 100.f, AudioParameterFloatAttributes().withLabel ("%")));
    return { p.begin(), p.end() };
}

bool VocalNoteProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    auto out = layouts.getMainOutputChannelSet();
    if (out != juce::AudioChannelSet::mono() && out != juce::AudioChannelSet::stereo()) return false;
    return layouts.getMainInputChannelSet() == out;
}

void VocalNoteProcessor::prepareToPlay (double sampleRate, int)
{
    dsp.prepare (sampleRate);
    setLatencySamples (dsp.getLatency());   // Ableton compensa este retraso automáticamente
}

void VocalNoteProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    const int numCh = buffer.getNumChannels();
    const int n = buffer.getNumSamples();

    dsp.amount     = pAmount->load() * 0.01f;
    dsp.retuneMs   = pSpeed->load();
    dsp.bendRange  = pBend->load();
    dsp.holdLast   = pHold->load() > 0.5f;
    dsp.mix        = pMix->load() * 0.01f;
    dsp.transpose  = pTranspose->load();
    dsp.voicedThresh = juce::jmap (pSens->load() * 0.01f, 0.15f, 0.6f);

    auto* L = buffer.getWritePointer (0);
    auto* R = numCh > 1 ? buffer.getWritePointer (1) : nullptr;

    auto it = midi.cbegin();
    for (int i = 0; i < n; ++i)
    {
        while (it != midi.cend() && (*it).samplePosition <= i)
        {
            const auto m = (*it).getMessage();
            if (m.isNoteOn())                     { dsp.noteOn (m.getNoteNumber()); uiMidiSeen = true; }
            else if (m.isNoteOff())               dsp.noteOff (m.getNoteNumber());
            else if (m.isPitchWheel())            dsp.pitchBend (m.getPitchWheelValue());
            else if (m.isAllNotesOff() || m.isAllSoundOff()) dsp.allNotesOff();
            ++it;
        }
        const float x = R ? 0.5f * (L[i] + R[i]) : L[i];
        const float y = dsp.processSample (x);
        L[i] = y;
        if (R) R[i] = y;
    }
    for (int c = 2; c < numCh; ++c) buffer.clear (c, 0, n);

    uiDetected = dsp.dispDetected;
    uiTarget   = dsp.dispTarget;
    uiOut      = dsp.dispOut;
}

juce::AudioProcessorEditor* VocalNoteProcessor::createEditor() { return new VocalNoteEditor (*this); }

void VocalNoteProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    if (auto xml = apvts.copyState().createXml()) copyXmlToBinary (*xml, destData);
}

void VocalNoteProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary (data, sizeInBytes))
        if (xml->hasTagName (apvts.state.getType()))
            apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new VocalNoteProcessor(); }
