#pragma once
#include <JuceHeader.h>
#include "VocalNoteDSP.h"

class VocalNoteProcessor : public juce::AudioProcessor
{
public:
    VocalNoteProcessor();
    ~VocalNoteProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "VocalNote"; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState apvts;
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();

    // para la interfaz (escritos por el hilo de audio)
    std::atomic<float> uiDetected { 0.f }, uiTarget { -1.f }, uiOut { 0.f };
    std::atomic<bool>  uiMidiSeen { false };

private:
    VocalNoteDSP dsp;
    std::atomic<float>* pAmount = nullptr;
    std::atomic<float>* pSpeed = nullptr;
    std::atomic<float>* pBend = nullptr;
    std::atomic<float>* pHold = nullptr;
    std::atomic<float>* pMix = nullptr;
    std::atomic<float>* pTranspose = nullptr;
    std::atomic<float>* pSens = nullptr;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (VocalNoteProcessor)
};
