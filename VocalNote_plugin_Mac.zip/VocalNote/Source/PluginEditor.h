#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class VocalNoteEditor : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit VocalNoteEditor (VocalNoteProcessor&);
    ~VocalNoteEditor() override;
    void paint (juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;

    struct Knob
    {
        juce::Slider slider;
        juce::Label label;
        std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> att;
    };

    VocalNoteProcessor& proc;
    juce::LookAndFeel_V4 lnf;
    std::array<Knob, 6> knobs;
    juce::ToggleButton holdButton { "Mantener ultima nota" };
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> holdAtt;

    static constexpr int histLen = 240; // ~8 s a 30 fps
    std::array<float, histLen> histDet {}, histTgt {}, histOut {};
    int histPos = 0;
    juce::Rectangle<int> graphArea;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (VocalNoteEditor)
};
