// VocalNoteDSP.h — motor de corrección de tono guiado por MIDI.
// Detección de tono: YIN. Desplazamiento: PSOLA en tiempo real (conserva formantes).
// Sin dependencias: se usa tanto en el plugin JUCE como en la prueba offline.
#pragma once
#include <vector>
#include <cmath>
#include <algorithm>

class VocalNoteDSP
{
public:
    // ---- parámetros (se pueden cambiar en cualquier momento) ----
    float amount      = 1.0f;   // 0..1  cuánto se corrige hacia la nota MIDI
    float retuneMs    = 20.0f;  // 0..500 ms  tiempo para llegar a la nota
    float bendRange   = 2.0f;   // semitonos del pitch bend
    bool  holdLast    = false;  // sin nota: false = voz original, true = mantener la última nota
    float mix         = 1.0f;   // 0..1 seco/procesado
    float transpose   = 0.0f;   // semitonos sumados a la nota MIDI
    float minFreq     = 70.0f;  // Hz, límite inferior de detección
    float maxFreq     = 1000.0f;// Hz, límite superior
    float voicedThresh = 0.4f;  // tolerancia de detección (más alto = detecta voz más ruidosa)

    void prepare (double sampleRate)
    {
        sr = sampleRate;
        Tmax = (int) std::ceil (sr / minFreq);
        Tmin = std::max (2, (int) std::floor (sr / maxFreq));
        yinW = std::max (Tmax * 2, 1024);
        hop  = std::max (128, (int) std::round (sr * 0.004)); // ~4 ms
        latency = Tmax * 3 + yinW / 2 + hop + 64;
        N = 1;
        while (N < latency * 2 + yinW + Tmax * 4 + 4096) N <<= 1;
        mask = N - 1;
        in.assign (N, 0.f); ola.assign (N, 0.f);
        note.assign (N, -1.f); f0buf.assign (N, 0.f);
        yd.assign (Tmax + 2, 0.f);
        reset();
    }

    void reset()
    {
        std::fill (in.begin(), in.end(), 0.f);
        std::fill (ola.begin(), ola.end(), 0.f);
        std::fill (note.begin(), note.end(), -1.f);
        std::fill (f0buf.begin(), f0buf.end(), 0.f);
        t = 0; nextSynth = 0; anaMark = 0; lastHop = 0;
        curNote = -1; heldNote = -1.f; bend = 0.f; shiftSm = 0.f;
        lastF0 = 0.f; heldStack.clear();
        dispDetected = 0.f; dispTarget = -1.f;
    }

    int getLatency() const { return latency; }

    // ---- MIDI ----
    void noteOn (int n)  { heldStack.erase (std::remove (heldStack.begin(), heldStack.end(), n), heldStack.end());
                           heldStack.push_back (n); updateNote(); }
    void noteOff (int n) { heldStack.erase (std::remove (heldStack.begin(), heldStack.end(), n), heldStack.end());
                           updateNote(); }
    void allNotesOff()   { heldStack.clear(); updateNote(); }
    void pitchBend (int v14) { bend = (float) (v14 - 8192) / 8192.f * bendRange; }

    // ---- audio: procesa una muestra mono ----
    inline float processSample (float x)
    {
        in[t & mask] = x;
        float tgt = (heldStack.empty() ? (holdLast ? heldNote : -1.f) : (float) heldStack.back());
        note[t & mask] = tgt < 0 ? -1.f : tgt + bend + transpose;

        if (t - lastHop >= hop) { analyse(); lastHop = t; }

        // generar granos mientras haga falta
        while (nextSynth <= t - latency + Tmax + 8)
            makeGrain();

        long long r = t - latency;
        float y = 0.f, dry = 0.f;
        if (r >= 0)
        {
            int i = (int) (r & mask);
            y = ola[i];
            ola[i] = 0.f;
            dry = in[i];
        }
        ++t;
        return dry + (y - dry) * mix;
    }

    // para la interfaz
    float dispDetected = 0.f; // nota MIDI detectada (fraccional), 0 = sin voz
    float dispTarget = -1.f;  // nota objetivo, -1 = ninguna
    float dispOut = 0.f;      // tono resultante estimado, 0 = sin voz

private:
    double sr = 44100;
    std::vector<float> in, ola, note, f0buf, yd;
    int Tmax = 630, Tmin = 44, yinW = 1260, hop = 176, latency = 2000, N = 8192, mask = 8191;
    long long t = 0, nextSynth = 0, anaMark = 0, lastHop = 0;
    int curNote = -1;
    int unvoicedRun = 0;
    float heldNote = -1.f, bend = 0.f, shiftSm = 0.f, lastF0 = 0.f;
    std::vector<int> heldStack;

    void updateNote() { if (! heldStack.empty()) heldNote = (float) heldStack.back(); }

    // YIN sobre la ventana que termina en t; el resultado se asigna al centro de la ventana
    void analyse()
    {
        long long end = t;                 // última muestra escrita
        long long start = end - (yinW + Tmax);
        if (start < 0) return;
        const int W = yinW;
        float run = 0.f;
        yd[0] = 1.f;
        float energy = 0.f;
        for (int j = 0; j < W; ++j) { float a = in[(start + j) & mask]; energy += a * a; }
        float f0 = 0.f;
        if (energy / W > 1e-7f)
        {
            for (int tau = 1; tau <= Tmax; ++tau)
            {
                float d = 0.f;
                for (int j = 0; j < W; j += 2) // submuestreo de la suma: suficiente y 2x más rápido
                {
                    float a = in[(start + j) & mask] - in[(start + j + tau) & mask];
                    d += a * a;
                }
                run += d;
                yd[tau] = run > 0 ? d * tau / run : 1.f;
            }
            int best = -1;
            for (int tau = Tmin; tau < Tmax; ++tau)
                if (yd[tau] < 0.15f) { while (tau + 1 < Tmax && yd[tau + 1] < yd[tau]) ++tau; best = tau; break; }
            if (best < 0) // voz ruidosa/procesada: aceptar el mínimo global si es razonable
            {
                int gm = Tmin;
                for (int tau = Tmin; tau < Tmax; ++tau) if (yd[tau] < yd[gm]) gm = tau;
                if (yd[gm] < voicedThresh) best = gm;
            }
            if (best > 0)
            {
                float a = yd[best - 1], b = yd[best], c = yd[best + 1];
                float den = a - 2 * b + c;
                float p = best + (std::abs (den) > 1e-9f ? 0.5f * (a - c) / den : 0.f);
                f0 = (float) (sr / p);
            }
        }
        // continuidad: corrige saltos de octava falsos (error típico de los detectores)
        if (f0 > 0.f)
        {
            if (lastF0 > 0.f)
            {
                float oct = std::log2 (f0 / lastF0);
                float r = std::round (oct);
                if (r != 0.f && std::abs (oct - r) < 0.12f) f0 *= std::pow (2.f, -r);
            }
            lastF0 = f0; unvoicedRun = 0;
        }
        else if (++unvoicedRun * hop > sr * 0.12) lastF0 = 0.f;

        // escribir f0 para el tramo [centro - hop, centro]
        long long centre = start + (W + Tmax) / 2;
        for (long long k = centre - hop; k <= centre; ++k) if (k >= 0) f0buf[k & mask] = f0;
    }

    void makeGrain()
    {
        long long s = nextSynth;
        float f0 = s >= 0 ? f0buf[s & mask] : 0.f;
        float tgt = s >= 0 ? note[s & mask] : -1.f;

        int Tin;
        float shift = 0.f;
        if (f0 > 0.f)
        {
            Tin = std::clamp ((int) std::lround (sr / f0), Tmin, Tmax);
            float det = 69.f + 12.f * std::log2 (f0 / 440.f);
            if (tgt >= 0.f)
            {
                float d = tgt - det;
                shift = d * amount;
            }
            dispDetected = det;
        }
        else
        {
            Tin = (int) std::lround (sr * 0.005); // sin voz: granos de 10 ms, sin cambio
            dispDetected = 0.f;
        }
        dispTarget = tgt;

        // suavizado (retune speed), por tiempo transcurrido desde el último grano
        float dt = (float) Tin / (float) sr;
        float tau = retuneMs * 0.001f;
        float k = tau <= 0.0005f ? 1.f : 1.f - std::exp (-dt / tau);
        shiftSm += (shift - shiftSm) * k;
        if (f0 <= 0.f) shiftSm *= 0.5f; // en consonantes vuelve rápido a 0

        dispOut = f0 > 0.f ? dispDetected + shiftSm : 0.f;
        float ratio = std::pow (2.f, std::clamp (shiftSm, -24.f, 24.f) / 12.f);
        int Tout = std::max (8, (int) std::lround (Tin / ratio));

        // marca de análisis más cercana a s, avanzando en pasos de Tin
        if (anaMark < s - 4 * Tmax) anaMark = s;
        while (anaMark + Tin / 2 < s) anaMark += Tin;

        // compensación de nivel: al bajar el tono quedan huecos entre granos
        float g = Tout > Tin ? std::pow ((float) Tout / (float) Tin, 0.8f) : 1.f;
        for (int j = -Tin; j <= Tin; ++j)
        {
            float w = 0.5f + 0.5f * std::cos ((float) M_PI * j / (float) Tin);
            long long src = anaMark + j, dst = s + j;
            if (src < 0 || dst < 0) continue;
            ola[dst & mask]  += w * g * in[src & mask];
        }
        nextSynth += Tout;
    }
};
