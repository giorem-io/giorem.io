cmake_minimum_required(VERSION 3.22)

# En Mac: compila para Apple Silicon (arm64). Para Intel cambia a "x86_64" o usa "arm64;x86_64".
if(APPLE)
    set(CMAKE_OSX_ARCHITECTURES "arm64" CACHE STRING "")
    set(CMAKE_OSX_DEPLOYMENT_TARGET "11.0" CACHE STRING "")
endif()

project(VocalNote VERSION 1.0.0)

include(FetchContent)
if(EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/JUCE/CMakeLists.txt")
    add_subdirectory(JUCE)
else()
    FetchContent_Declare(JUCE
        GIT_REPOSITORY https://github.com/juce-framework/JUCE.git
        GIT_TAG 8.0.15
        GIT_SHALLOW TRUE)
    FetchContent_MakeAvailable(JUCE)
endif()

juce_add_plugin(VocalNote
    COMPANY_NAME "VocalNote"
    BUNDLE_ID "com.vocalnote.vocalnote"
    PLUGIN_MANUFACTURER_CODE Vcnt
    PLUGIN_CODE Vcn1
    FORMATS AU VST3
    PRODUCT_NAME "VocalNote"
    IS_SYNTH FALSE
    NEEDS_MIDI_INPUT TRUE          # recibe notas MIDI (en AU se registra como "music effect")
    NEEDS_MIDI_OUTPUT FALSE
    IS_MIDI_EFFECT FALSE
    EDITOR_WANTS_KEYBOARD_FOCUS FALSE
    COPY_PLUGIN_AFTER_BUILD TRUE   # se instala solo en ~/Library/Audio/Plug-Ins
    VST3_CATEGORIES Fx Pitch Shift)

juce_generate_juce_header(VocalNote)

target_sources(VocalNote PRIVATE
    Source/PluginProcessor.cpp
    Source/PluginEditor.cpp)

target_compile_features(VocalNote PRIVATE cxx_std_17)

target_compile_definitions(VocalNote PUBLIC
    JUCE_WEB_BROWSER=0
    JUCE_USE_CURL=0
    JUCE_VST3_CAN_REPLACE_VST2=0
    JUCE_VST3_EMULATE_MIDI_CC_WITH_PARAMETERS=0
    JUCE_DISPLAY_SPLASH_SCREEN=0)

target_link_libraries(VocalNote
    PRIVATE
        juce::juce_audio_utils
        juce::juce_dsp
    PUBLIC
        juce::juce_recommended_config_flags
        juce::juce_recommended_lto_flags)
